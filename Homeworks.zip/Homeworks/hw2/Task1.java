import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;
public class Task1 {
    public static void main(String args[]) {
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		int length = 15;
		
		// //	а		
		// int[] arr = new int[length];
		// for (int i = 0; i < length; i++) {
		// 	arr[i] = random.nextInt(100);
		// }
		// System.out.println("Изначальный массив: " + Arrays.toString(arr));

		// int[] arr1 = new int[7];
		// int y = 0;
		// for (int x = 8; x >= 2 ; x--) {
		// 	arr1[y] = arr[x];
		
		// 	y++;
		// }

		
		// int e = 0;


		// for (int x = 2; x <= 8; x++) {
		// 	arr[x] = arr1[e];
		// 	e++;
		// }
 		// System.out.println("а) " + Arrays.toString(arr));
		
		
		//	б
		
		// int[] arrb = new int[length];
		// for (int i = 0; i < length; i++) {


		// 	arrb[i] = random.nextInt(100);
		// }
		// System.out.println(Arrays.toString(arrb));
		
		// System.out.println("Введите k и s:");
		// int k = scanner.nextInt();
		// int s = scanner.nextInt();
		
		// int[] arr2 = new int[length];

		// int l = 0;
		// for (int x = s - 2; x >= k ; x--) {

		// 	arr2[l] = arrb[x];
		// 	l++;
		// }
		
		// int h = 0;
		// for (int x = k; x <= (s - 2); x++) {
		// 	arrb[x] = arr2[h];
		// 	h++;
		// }
		// System.out.println(Arrays.toString(arrb));
		
		// 	в
		
		// int[] arrv = new int[length];
		// for (int i = 0; i < length; i++) {
		// 	arrv[i] = random.nextInt(100);
		// }
		// System.out.println(Arrays.toString(arrv));
		
		// int inmin = 0;
		// int inmax = 0;
		// int min = 1000;
		// int max = 0;
		// for (int x = 0; x < length; x++) {
		// 	if (arrv[x] < min) {
		// 		min = arrv[x];
		// 		inmin = x;
		// 	}
		// 	if (arrv[x] > max) {
		// 		max = arrv[x];
		// 		inmax = x;
		// 	}
		// }
		
		
		// int[] arr3 = new int[length];
		// int g = 0;
		// if (inmax > inmin) {
		// 	for (int x = inmax; x >= inmin ; x--) {
		// 		arr3[g] = arrv[x];
		// 		g++;
		// 	}
			
		// 	int c = 0;
		// 	for (int x = inmin; x <= inmax; x++) {
		// 		arrv[x] = arr3[c];
		// 		c++;
		// 	}
		// 	System.out.println(Arrays.toString(arrv));
		// }
		
		// if (inmin > inmax) {
		// 	for (int x = inmin; x >= inmax ; x--) {
		// 		arr3[g] = arrv[x];
		// 		g++;
		// 	}
			
		// 	int c = 0;
		// 	for (int x = inmax; x <= inmin; x++) {
		// 		arrv[x] = arr3[c];
		// 		c++;
		// 	}
		// 	System.out.println(Arrays.toString(arrv));
		// }
		
			
		
		
	
	}
}
		