public class Lion implements Animal{
	public void makeSound(){
		System.out.println("MEOW");
	}
	public void eat(String food){
		System.out.println("Lion eats"+food);
	}
	public void hunt(){
		System.out.println("Lion is hunting");
	}
}