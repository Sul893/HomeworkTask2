public class Lion implements Animal{
	public void makeSound(){
		System.out.println("uga buga");
	}
	public void eat(String food){
		System.out.println("Monkey eats"+food);
	}
	public void swing(){
		System.out.println("Monkey is swining");
	}
}