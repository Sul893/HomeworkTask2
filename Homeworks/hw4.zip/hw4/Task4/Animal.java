public interface Animal{
	private void makesound();
	private void eat(String food);
}