public class Lion implements Animal{
	public void makeSound(){
		System.out.println("trublu");
	}
	public void eat(String food){
		System.out.println("Elephant eats"+food);
	}
	public void playWater(){
		System.out.println("Elephant is playing water");
	}
}